#include <iostream>
#include <fstream>
#include <map>
#include <string>

// Class to track grocery items and their frequencies
class GroceryTracker {
public:
    // Constructor: Loads data from file and saves frequency data to another file
    GroceryTracker(const std::string& inputFile) {
        LoadData(inputFile);           // Load item frequencies from the input file
        SaveToFile("frequency.dat");  // Save item frequencies to "frequency.dat"
    }

    // Searches for an item and prints its frequency
    void SearchItem(const std::string& item) const {
        auto it = itemFrequency.find(item);  // Find the item in the map
        if (it != itemFrequency.end()) {
            std::cout << item << " appears " << it->second << " times." << std::endl;
        }
        else {
            std::cout << item << " not found." << std::endl;
        }
    }

    // Prints the frequency of all items
    void PrintFrequencies() const {
        for (const auto& pair : itemFrequency) {  // Iterate over all items in the map
            std::cout << pair.first << " " << pair.second << std::endl;
        }
    }

    // Prints a histogram of item frequencies
    void PrintHistogram() const {
        for (const auto& pair : itemFrequency) {  // Iterate over all items in the map
            std::cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";  // Print asterisks corresponding to frequency
            }
            std::cout << std::endl;
        }
    }

private:
    std::map<std::string, int> itemFrequency;  // Map to store item frequencies

    // Loads item data from the input file
    void LoadData(const std::string& inputFile) {
        std::ifstream inFile(inputFile);  // Open the input file
        std::string item;

        if (!inFile) {  // Check if the file opened successfully
            std::cerr << "Error opening file: " << inputFile << std::endl;
            return;
        }

        while (inFile >> item) {  // Read items from the file
            itemFrequency[item]++;  // Increment the count for each item
        }
    }

    // Saves item frequencies to the output file
    void SaveToFile(const std::string& outputFile) const {
        std::ofstream outFile(outputFile);  // Open the output file

        if (!outFile) {  // Check if the file opened successfully
            std::cerr << "Error opening file: " << outputFile << std::endl;
            return;
        }

        for (const auto& pair : itemFrequency) {  // Iterate over all items in the map
            outFile << pair.first << " " << pair.second << std::endl;  // Write item and its frequency
        }
    }
};

// Validates user input to ensure it is a number between 1 and 4
void ValidateUserInput(int& choice) {
    while (!(std::cin >> choice) || choice < 1 || choice > 4) {  // Check for valid input
        std::cin.clear();  // Clear the error flag
        std::cin.ignore(1000, '\n');  // Ignore the invalid input
        std::cout << "Invalid input. Please enter a number between 1 and 4: ";
    }
}

int main() {
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt");  // Create GroceryTracker object and load data from "CS210_Project_Three_Input_File.txt"

    int choice;
    std::string item;

    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. Search for an item\n";
        std::cout << "2. Print frequency of all items\n";
        std::cout << "3. Print histogram of items\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";

        ValidateUserInput(choice);  // Validate user input

        switch (choice) {
        case 1:
            std::cout << "Enter item to search for: ";
            std::cin >> item;
            tracker.SearchItem(item);  // Search for the item and display frequency
            break;
        case 2:
            tracker.PrintFrequencies();  // Print frequency of all items
            break;
        case 3:
            tracker.PrintHistogram();  // Print histogram of item frequencies
            break;
        case 4:
            std::cout << "Exiting program." << std::endl;
            break;
        default:
            std::cout << "Invalid choice, please try again." << std::endl;
        }
    } while (choice != 4);  // Continue until the user chooses to exit

    return 0;
}
